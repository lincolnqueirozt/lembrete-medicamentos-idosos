# Lembrete de Medicamentos - TEDI (UTFPR)

Projeto-base para o aplicativo móvel de lembretes de medicamentos.

## Estrutura inicial
- /lib/models
- /lib/services
- /lib/pages
- /db/scripts.sql

## Execução local (Flutter)
1. Instale o Flutter (https://flutter.dev)
2. `flutter pub get`
3. `flutter run`

## Observações
- Este scaffold inclui funcionalidades mínimas: CRUD de medicamentos e estrutura para lembretes.
- Ajuste `usuarioId` ao criar usuários reais.
- Configure permissões e ícones para notificações em Android/iOS.