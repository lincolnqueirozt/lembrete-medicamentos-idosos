-- Scripts SQL para criação das tabelas principais (SQLite / SQL padrão)

CREATE TABLE usuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    data_nascimento DATE,
    telefone TEXT,
    email TEXT
);

CREATE TABLE medicamento (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    nome TEXT NOT NULL,
    dosagem TEXT,
    frequencia TEXT, -- ex: "8:00,20:00" ou expressão
    observacoes TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

CREATE TABLE lembrete (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    medicamento_id INTEGER NOT NULL,
    horario TIME NOT NULL,
    mensagem TEXT,
    ativo BOOLEAN DEFAULT 1,
    FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
);

CREATE TABLE historico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    medicamento_id INTEGER NOT NULL,
    data DATE NOT NULL,
    hora TIME NOT NULL,
    tomado BOOLEAN DEFAULT 0,
    observacao TEXT,
    FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
);