import 'package:flutter/material.dart';
import '../services/db_helper.dart';
import '../models/medicamento.dart';
import 'add_medicamento_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final DBHelper db = DBHelper();
  List<Medicamento> lista = [];

  @override
  void initState() {
    super.initState();
    carregar();
  }

  Future<void> carregar() async {
    final dados = await db.getMedicamentos();
    setState(() {
      lista = dados.map((m) => Medicamento.fromMap(m)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lembretes')),
      body: ListView.builder(
        itemCount: lista.length,
        itemBuilder: (context, i) {
          final m = lista[i];
          return ListTile(
            title: Text(m.nome),
            subtitle: Text('${m.dosagem} • ${m.frequencia}'),
            trailing: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () async {
                if (m.id != null) await db.deleteMedicamento(m.id!);
                carregar();
              },
            ),
            onTap: () {
              // abrir edição futuramente
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () async {
          final res = await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddMedicamentoPage()));
          if (res == true) carregar();
        },
      ),
    );
  }
}