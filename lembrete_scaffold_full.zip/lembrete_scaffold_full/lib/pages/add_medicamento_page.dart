import 'package:flutter/material.dart';
import '../services/db_helper.dart';
import '../models/medicamento.dart';

class AddMedicamentoPage extends StatefulWidget {
  const AddMedicamentoPage({super.key});
  @override
  State<AddMedicamentoPage> createState() => _AddMedicamentoPageState();
}

class _AddMedicamentoPageState extends State<AddMedicamentoPage> {
  final _formKey = GlobalKey<FormState>();
  final _nomeCtrl = TextEditingController();
  final _dosagemCtrl = TextEditingController();
  final _freqCtrl = TextEditingController();
  final DBHelper db = DBHelper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adicionar Medicamento')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: _nomeCtrl, decoration: const InputDecoration(labelText: 'Nome'), validator: (v) => v == null || v.isEmpty ? 'Preencha' : null),
              TextFormField(controller: _dosagemCtrl, decoration: const InputDecoration(labelText: 'Dosagem')),
              TextFormField(controller: _freqCtrl, decoration: const InputDecoration(labelText: 'Frequência (ex: 08:00,20:00)')),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Salvar'),
                onPressed: () async {
                  if (_formKey.currentState?.validate() ?? false) {
                    final med = Medicamento(
                      usuarioId: 1, // temporário (criar usuário padrão)
                      nome: _nomeCtrl.text,
                      dosagem: _dosagemCtrl.text,
                      frequencia: _freqCtrl.text,
                    );
                    await db.insertMedicamento(med.toMap());
                    Navigator.pop(context, true);
                  }
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}