import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'lembretes.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE usuario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        data_nascimento TEXT,
        telefone TEXT,
        email TEXT
      );
    ''');

    await db.execute('''
      CREATE TABLE medicamento (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        nome TEXT NOT NULL,
        dosagem TEXT,
        frequencia TEXT,
        observacoes TEXT,
        FOREIGN KEY (usuario_id) REFERENCES usuario(id)
      );
    ''');

    await db.execute('''
      CREATE TABLE lembrete (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicamento_id INTEGER NOT NULL,
        horario TEXT NOT NULL,
        mensagem TEXT,
        ativo INTEGER DEFAULT 1,
        FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
      );
    ''');

    await db.execute('''
      CREATE TABLE historico (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicamento_id INTEGER NOT NULL,
        data TEXT NOT NULL,
        hora TEXT NOT NULL,
        tomado INTEGER DEFAULT 0,
        observacao TEXT,
        FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
      );
    ''');
  }

  // Exemplo de CRUD para medicamento:
  Future<int> insertMedicamento(Map<String, dynamic> map) async {
    final db = await database;
    return await db.insert('medicamento', map);
  }

  Future<List<Map<String, dynamic>>> getMedicamentos() async {
    final db = await database;
    return await db.query('medicamento');
  }

  Future<int> updateMedicamento(Map<String, dynamic> map) async {
    final db = await database;
    return await db.update('medicamento', map, where: 'id = ?', whereArgs: [map['id']]);
  }

  Future<int> deleteMedicamento(int id) async {
    final db = await database;
    return await db.delete('medicamento', where: 'id = ?', whereArgs: [id]);
  }
}