class Historico {
  int? id;
  int medicamentoId;
  String data; // YYYY-MM-DD
  String hora; // HH:MM
  bool tomado;
  String? observacao;

  Historico({
    this.id,
    required this.medicamentoId,
    required this.data,
    required this.hora,
    this.tomado = false,
    this.observacao
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'medicamento_id': medicamentoId,
    'data': data,
    'hora': hora,
    'tomado': tomado ? 1 : 0,
    'observacao': observacao,
  };

  factory Historico.fromMap(Map<String, dynamic> m) => Historico(
    id: m['id'],
    medicamentoId: m['medicamento_id'],
    data: m['data'],
    hora: m['hora'],
    tomado: m['tomado'] == 1,
    observacao: m['observacao']
  );
}