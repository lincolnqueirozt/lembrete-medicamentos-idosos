class Medicamento {
  int? id;
  int usuarioId;
  String nome;
  String dosagem;
  String frequencia; // ex: "08:00,20:00" ou formato humano
  String? observacoes;

  Medicamento({
    this.id,
    required this.usuarioId,
    required this.nome,
    required this.dosagem,
    required this.frequencia,
    this.observacoes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'usuario_id': usuarioId,
      'nome': nome,
      'dosagem': dosagem,
      'frequencia': frequencia,
      'observacoes': observacoes,
    };
  }

  factory Medicamento.fromMap(Map<String, dynamic> map) {
    return Medicamento(
      id: map['id'],
      usuarioId: map['usuario_id'],
      nome: map['nome'],
      dosagem: map['dosagem'],
      frequencia: map['frequencia'],
      observacoes: map['observacoes'],
    );
  }
}