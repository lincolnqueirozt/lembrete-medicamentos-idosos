class Lembrete {
  int? id;
  int medicamentoId;
  String horario; // "08:00"
  String? mensagem;
  bool ativo;

  Lembrete({this.id, required this.medicamentoId, required this.horario, this.mensagem, this.ativo = true});

  Map<String, dynamic> toMap() => {
    'id': id,
    'medicamento_id': medicamentoId,
    'horario': horario,
    'mensagem': mensagem,
    'ativo': ativo ? 1 : 0,
  };

  factory Lembrete.fromMap(Map<String, dynamic> m) => Lembrete(
    id: m['id'],
    medicamentoId: m['medicamento_id'],
    horario: m['horario'],
    mensagem: m['mensagem'],
    ativo: m['ativo'] == 1,
  );
}