class Usuario {
  int? id;
  String nome;
  DateTime? dataNascimento;
  String? telefone;
  String? email;

  Usuario({this.id, required this.nome, this.dataNascimento, this.telefone, this.email});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nome': nome,
      'data_nascimento': dataNascimento?.toIso8601String(),
      'telefone': telefone,
      'email': email,
    };
  }

  factory Usuario.fromMap(Map<String, dynamic> map) {
    return Usuario(
      id: map['id'],
      nome: map['nome'],
      dataNascimento: map['data_nascimento'] != null ? DateTime.parse(map['data_nascimento']) : null,
      telefone: map['telefone'],
      email: map['email'],
    );
  }
}